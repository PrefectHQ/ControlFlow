from marvin.utilities.context import ScopedContext

ctx = ScopedContext()
